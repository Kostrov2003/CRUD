import requests
from db import books

def read():
  print(books)


def add():
  print('Введите позицию ,затем введите имя автора и название книги ')
  print('позиция')
  a = int(input())
  print('книга')
  name_book = str(input())
  position = a - 1
  books.insert(position,name_book)
  print(books)


def delete():
  print(books)
  print('Что вы хотите удалить?')
  delete = str(input())
  books.remove(delete)
  print(books)


def create():
  print('Позиция книги')
  numbers = int(input())
  print('На что изменить (редактировать) книгу ')
  rename_books = input()
  position = numbers - 1
  books.pop(position)
  books.insert(position,rename_books)
  print(books)


while True:
  print('Что будем делать? (add, read, create, delete, exit)')
  request = input()
  if request == 'add':
    add()
  elif request == 'read':
    read()
  elif request == 'create':
    create()
  elif request == 'delete':
    delete()
  elif request == 'exit':
    break
  else:
    print('Повторите попытку')
  


result = requests.post('https://serverpy.21yroslav10.repl.co/books',data = {'library': books})

print(result)


    


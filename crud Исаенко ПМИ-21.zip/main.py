from flask import Flask
import requests
from db import books




app = Flask('Library')

@app.route('/books')

def book():
  return {'books': books}

@app.route('/books', methods=['POST'])
def late():
    books = requests.form['books']
    books.append({'books': books})
    return {'books':books }







app.run(host = '0.0.0.0', port=3000)

